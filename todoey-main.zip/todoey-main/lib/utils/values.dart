import 'package:flutter/material.dart';

// Icons
const personIcon = 0xe491;
const worklcon = 0xe11c;
const movieIcon = 0xe40f;
const sporticon = 0xe4dc;
const travelIcon = 0xe071;
const shoplcon = 0xe59c;

// Colors
const purple = Color(0xFF756BFC);
const pink = Color(0xFFF1A39A);
const deepPink = Color(0xFFFA63C6);
const green = Color(0xFF41CF9F);
const yellow = Color(0xFFEEC38E);
const tightBIue = Color(0xFF42A5F5);
const blue = Color(0xFF2B60E6);
